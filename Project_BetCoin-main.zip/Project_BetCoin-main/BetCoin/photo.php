<?php
    echo "<h1>user list<h1>";
    echo "<table border='1'>";
    echo "<tr>";
    echo "<td>";
    echo "<a href='image/001.png' >";
    echo "<img src='image/001.png' style='width:100; height:100;'>";
    echo "</a>";
    echo "</td>";
    echo "</tr>";
    echo "</table>";
?>