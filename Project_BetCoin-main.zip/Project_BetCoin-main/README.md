# Project_BetCoin
# Project describe:
BitCoin is the website that can bet on your favorite team swhen the team you bet on win, you can get the money that multiply betting odds.
</br>The project has finish the Front-End and Back-End.
</br>Login Back-End via admin account

# Important information you have to know
1. The SQL file include the data the file name is 'betcoin.sql' in the folder 'SQL'.
2. <h3>The Forgot Password need to be modify, in the file /BetCoin/mailSend.php add the code in the line 33 and 34, you have to enter your email in line 33 apostrophe and enter your email password in line 34.</h3>
3. If you want to login the Back-End you need to login by the admin account:
<table>
  <tr>
    <td>email:</td><td> w@q.w</td>
  </tr>
  <tr>
    <td>Password:</td><td>321</td>
  </tr>
</table>
